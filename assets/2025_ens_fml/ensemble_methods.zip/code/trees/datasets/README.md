## Example data

- I copied this data from LightGBM's regression example data.
- original data: https://github.com/Microsoft/LightGBM/tree/master/examples/regression
